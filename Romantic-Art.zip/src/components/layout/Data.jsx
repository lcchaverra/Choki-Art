import cartImage1 from "../../assets/images/Imagen 1.jpg"
import cartImage2 from "../../assets/images/Imagen 2.jpg"
import cartImage3 from "../../assets/images/Imagen 3.jpg"
import cartImage4 from "../../assets/images/Imagen 4.jpg"
import cartImage5 from "../../assets/images/Imagen 5.jpg"
import cartImage6 from "../../assets/images/Imagen 6.jpg"
import cartImage7 from "../../assets/images/Imagen 7.jpg"
import cartImage8 from "../../assets/images/Imagen 8.jpg"
import cartImage9 from "../../assets/images/Imagen 9.jpg"
import cartImage10 from "../../assets/images/Imagen 10.jpg"
import cartImage11 from "../../assets/images/Imagen 11.jpg"
import cartImage12 from "../../assets/images/Imagen 12.jpg"
import cartImage13 from "../../assets/images/Imagen 13.jpg"
import cartImage14 from "../../assets/images/Imagen 14.jpg"
import cartImage15 from "../../assets/images/Imagen 15.jpg"
import cartImage16 from "../../assets/images/Imagen 16.jpg"
import cartImage17 from "../../assets/images/Imagen 17.jpg"

export const data = [
    {
        id: 1,
        title: "Obra 1",
        price: "10000",
        img: cartImage1
    },
    {
        id: 2,
        title: "Obra 2",
        price: "17000",
        img: cartImage2
    },
    {
        id: 3,
        title: "Obra 3",
        price: "20000",
        img: cartImage3
    },
    {
        id: 4,
        title: "Obra 4",
        price: "21000",
        img: cartImage4
    },
    {
        id: 5,
        title: "Obra 5",
        price: "31000",
        img: cartImage5
    },
    {
        id: 6,
        title: "Obra 6",
        price: "35000",
        img: cartImage6
    },
    {
        id: 7,
        title: "Obra 7",
        price: "41000",
        img: cartImage7
    },
    {
        id: 8,
        title: "Obra 8",
        price: "23000",
        img: cartImage8
    },
    {
        id: 9,
        title: "Obra 9",
        price: "32000",
        img: cartImage9
    },
    {
        id: 10,
        title: "Obra 10",
        price: "1900",
        img: cartImage10
    },
    {
        id: 11,
        title: "Obra 11",
        price: "14000",
        img: cartImage11
    },
    {
        id: 12,
        title: "Obra 12",
        price: "43000",
        img: cartImage12
    },
    {
        id: 13,
        title: "Obra 13",
        price: "37000",
        img: cartImage13
    },
    {
        id: 14,
        title: "Obra 14",
        price: "75000",
        img: cartImage14
    },
    {
        id: 15,
        title: "Obra 15",
        price: "61000",
        img: cartImage15
    },
    {
        id: 16,
        title: "Obra 16",
        price: "61000",
        img: cartImage16
    },
    {
        id: 17,
        title: "Obra 17",
        price: "54000",
        img: cartImage17
    }
]